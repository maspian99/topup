<div id="pre-footer2"class="lb"></div>
        <div id="pre-footer" class="content-body pb-5 mb-6" >
            <div class="footer text-center pt-4 pb-10">
                <img src="<?= base_url(); ?>/assets/images/<?= $web['logo']; ?>" width="100" alt="logo icon" class="rounded">
                  <div class="sosmed pt-3">
                    <a href="<?= $sm['wa']; ?>" target="_blank" style="color: var(--warna_text);">
                        <i class="fa fa-whatsapp"></i>
                    </a>
                    <a href="<?= $sm['yt']; ?>" target="_blank" style="color: var(--warna_text);">
                        <i class="fa fa-youtube"></i>
                    </a>
                    
                    <a href="<?= $sm['tw']; ?>" target="_blank" style="color: var(--warna_text);">
                        <iconify-icon inline icon="fa-brands:tiktok" style="color: #81a1b1;"></iconify-icon>
                    </a>
                 </div>
                <p class="text-copyright" >© <?= strip_tags($web['name']); ?> <script>document.write(new Date().getFullYear());</script> - All Right Reserved</p>
                <p style="padding-bottom:100px"></p>
            </div>
        </div> 